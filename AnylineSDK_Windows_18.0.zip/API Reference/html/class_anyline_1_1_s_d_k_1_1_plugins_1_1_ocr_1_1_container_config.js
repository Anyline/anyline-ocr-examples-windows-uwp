var class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_container_config =
[
    [ "ContainerScanMode", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_container_config.html#a9f898f9f3fd7f95c7bf500f1b64b012e", [
      [ "Horizontal", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_container_config.html#a9f898f9f3fd7f95c7bf500f1b64b012eac1b5fa03ecdb95d4a45dd1c40b02527f", null ],
      [ "Vertical", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_container_config.html#a9f898f9f3fd7f95c7bf500f1b64b012ea06ce2a25e5d12c166a36f654dbea6012", null ]
    ] ],
    [ "ContainerConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_container_config.html#a81c3904c4dccd94c81372ac58c83903d", null ],
    [ "CharacterWhitelist", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_container_config.html#a5bd44b08d1223d7962fcd3a26945d5ef", null ],
    [ "ScanMode", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_container_config.html#a41f0510443c7d6ef1ad106c5069b1251", null ],
    [ "ValidationRegex", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_container_config.html#ad24973fd3042f51b7f224f3e0ec5c740", null ]
];