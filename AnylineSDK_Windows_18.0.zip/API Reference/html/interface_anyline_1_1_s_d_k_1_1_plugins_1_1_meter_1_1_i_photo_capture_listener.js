var interface_anyline_1_1_s_d_k_1_1_plugins_1_1_meter_1_1_i_photo_capture_listener =
[
    [ "OnPhotoCaptured", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_meter_1_1_i_photo_capture_listener.html#ade03db27c5de3cd1438c04d229841499", null ],
    [ "OnPhotoToFile", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_meter_1_1_i_photo_capture_listener.html#a297af3d43b409197e35661f2db9a139a", null ]
];