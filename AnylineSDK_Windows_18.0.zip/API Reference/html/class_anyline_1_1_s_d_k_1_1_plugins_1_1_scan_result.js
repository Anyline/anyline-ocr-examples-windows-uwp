var class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_result =
[
    [ "ScanResult", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_result.html#af6639452f71928c4ccbf4ae26c12d2f4", null ],
    [ "ToJson", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_result.html#a71ee721029f17a05909ff0d64d25d87d", null ],
    [ "PluginID", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_result.html#a5693f27fb0e8df6502ae5838dd22f2b0", null ]
];