var interface_anyline_1_1_s_d_k_1_1_models_1_1_i_anyline_scan_result =
[
    [ "ToJson", "interface_anyline_1_1_s_d_k_1_1_models_1_1_i_anyline_scan_result.html#ad2b7cff83d3a50c6f8b901425e6481fa", null ],
    [ "Confidence", "interface_anyline_1_1_s_d_k_1_1_models_1_1_i_anyline_scan_result.html#a3f89198ff429798f8596e139da48171d", null ],
    [ "CutoutImage", "interface_anyline_1_1_s_d_k_1_1_models_1_1_i_anyline_scan_result.html#a007a68b324f2be05fea07ea62ca6b9b5", null ],
    [ "FullImage", "interface_anyline_1_1_s_d_k_1_1_models_1_1_i_anyline_scan_result.html#a832c0f18dd8baf69010d54e574dc69c7", null ],
    [ "Outline", "interface_anyline_1_1_s_d_k_1_1_models_1_1_i_anyline_scan_result.html#a0eb04ca4495c59ee2921f04885dc46ba", null ],
    [ "Result", "interface_anyline_1_1_s_d_k_1_1_models_1_1_i_anyline_scan_result.html#ab6a99bd84623356c083fd15c8f9a2145", null ]
];