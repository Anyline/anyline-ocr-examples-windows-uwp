var class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config =
[
    [ "TINScanMode", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config.html#ad0c3755dcfdc2ca6e506b60620fcb72b", [
      [ "Standard", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config.html#ad0c3755dcfdc2ca6e506b60620fcb72baeb6d8ae6f20283755b339c0dc273988b", null ],
      [ "Flexible", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config.html#ad0c3755dcfdc2ca6e506b60620fcb72ba13b303a6c0d90897b5375ce901acc445", null ]
    ] ],
    [ "TINUpsideDownMode", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config.html#a46fe204e87ac7982d90f0f63bd669dd6", [
      [ "Disabled", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config.html#a46fe204e87ac7982d90f0f63bd669dd6ab9f5c797ebbf55adccdd8539a65a0241", null ],
      [ "Enabled", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config.html#a46fe204e87ac7982d90f0f63bd669dd6a00d23a76e43b46dae9ec7aa9dcbebb32", null ],
      [ "Auto", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config.html#a46fe204e87ac7982d90f0f63bd669dd6a06b9281e396db002010bde1de57262eb", null ]
    ] ],
    [ "TINConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config.html#accb7047b30947b51dc9637b9d794cef5", null ],
    [ "ScanMode", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config.html#a1c04225e53be7fd7b32eb2bfa3c3e9c2", null ],
    [ "UpsideDownMode", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config.html#a0fcce712e325e4cf44b92fcd48662dde", null ]
];