var interface_anyline_1_1_s_d_k_1_1_core_1_1_i_image_provider =
[
    [ "GetNewImage", "interface_anyline_1_1_s_d_k_1_1_core_1_1_i_image_provider.html#a280ea19914ffd63460560a5d4f6be2b9", null ],
    [ "HasNewImage", "interface_anyline_1_1_s_d_k_1_1_core_1_1_i_image_provider.html#a60c4027df0e06c1719293cdcbaffea4f", null ]
];