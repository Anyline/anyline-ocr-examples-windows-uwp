var class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_field_confidences =
[
    [ "IDFieldConfidences", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_field_confidences.html#a86615352dcb1bcf557f38388efe371e0", null ],
    [ "IDFieldConfidences", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_field_confidences.html#a38a9c17197b5f034407d91f1189e647a", null ],
    [ "ToJson", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_field_confidences.html#ac10e3a1978e9d949ce747ff4b008021f", null ],
    [ "defaultMinConfidence", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_field_confidences.html#adfad6449829de51c9f266bf011bec151", null ]
];