var class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_base_config =
[
    [ "AnylineOcrBaseConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_base_config.html#a74b299d8a09905c5e6186136441916c6", null ],
    [ "AnylineOcrBaseConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_base_config.html#aa37bf21c5958538891befce51f83f17d", null ],
    [ "AnylineOcrBaseConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_base_config.html#a04e874f14ed3b6d3d7ec026d5a3c4337", null ],
    [ "ToJsonString", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_base_config.html#a4cb21ad0deee3e3cf0b062e7299bea52", null ]
];