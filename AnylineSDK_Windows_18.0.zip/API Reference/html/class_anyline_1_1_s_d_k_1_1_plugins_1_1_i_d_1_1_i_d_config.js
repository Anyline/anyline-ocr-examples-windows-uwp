var class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_config =
[
    [ "IDConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_config.html#aa591eed19a9f53ed50dbf14d7090935e", null ],
    [ "IDConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_config.html#abd845960caad3256e8e10a4eb153f9c2", null ],
    [ "IDFieldScanOptions", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_config.html#aa13f1654252d28fde3fe74fb34eb2912", null ],
    [ "IDMinFieldConfidences", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_config.html#af7394264a77dfb723899044ad0fd67e3", null ],
    [ "MinConfidence", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_config.html#a0e5e883a673a61c990364f7fc7efc1e3", null ]
];