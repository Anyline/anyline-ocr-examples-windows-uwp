var class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_run_skipped_reason =
[
    [ "ScanRunSkippedReason", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_run_skipped_reason.html#aba71cfa5cd0b95547e288976031fe0e5", null ],
    [ "Code", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_run_skipped_reason.html#a335f805082ee2926b2400b2ca16199cd", null ],
    [ "PluginID", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_run_skipped_reason.html#a6767e2bf336ac5101e6d5684d370d5f8", null ],
    [ "Text", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_run_skipped_reason.html#adb14e42bc25ab718c3aca65fe3dc7eda", null ]
];