var class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_v_i_n_config =
[
    [ "VINConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_v_i_n_config.html#ac84cbf684b4b41caa40971228be8dcc4", null ],
    [ "CharacterWhitelist", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_v_i_n_config.html#aa9ab10d214e5158e90a963c2d6816807", null ],
    [ "ValidationRegex", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_v_i_n_config.html#a44683ab3d08da033a342e66a66dbf480", null ]
];