var class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language =
[
    [ "LanguageFileType", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#a5b859231c1edcf0c466d8baf836d5b06", [
      [ "Any", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#a5b859231c1edcf0c466d8baf836d5b06aed36a1ef76a59ee3f15180e0441188ad", null ],
      [ "Tesseract", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#a5b859231c1edcf0c466d8baf836d5b06af068c072fa1ea077a0b08d3f96a6f346", null ]
    ] ],
    [ "AnylineOcrLanguage", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#a5ae996fff18d7f544067c61ab26ebeef", null ],
    [ "FileType", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#aac81a75a57a455517c8f57b81be775c0", null ],
    [ "Md5", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#a0cba5201c0cd59e860a56d5bbc68d7e6", null ],
    [ "Name", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#ab2ac31b14ebcd948cbcc891b1e8ae219", null ],
    [ "Path", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#ab64520245aa0ccc7dc1913eb375334e2", null ]
];