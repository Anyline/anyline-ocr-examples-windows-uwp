var class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences =
[
    [ "GermanIDFrontFieldConfidences", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#a4a71f65ccb8afeae9d9853ec4f5b232e", null ],
    [ "GermanIDFrontFieldConfidences", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#a851eff686bc43a0a1ed663e15599a229", null ],
    [ "CardAccessNumber", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#a1db9fc994ae42fb52680ea6a77642d58", null ],
    [ "DateOfBirth", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#ae7b9f5c54c397e068fdee02df3bd9d55", null ],
    [ "DateOfBirthObject", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#a385508ae3cad166b651ce79a5b620b00", null ],
    [ "DateOfExpiry", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#a98aea96f8e68a04d368b37b71b97bb41", null ],
    [ "DateOfExpiryObject", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#a70b4451512c9d4d77a65ec55a0955058", null ],
    [ "DocumentNumber", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#a8347485ff62e30bc63f89c40117d2dee", null ],
    [ "GermanIdFrontString", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#a44e96da8ca602ebcb25f9a6c0fbbd28d", null ],
    [ "GivenNames", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#a18a5373cded226716237ae0892424b7c", null ],
    [ "Nationality", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#a2123e92984100f8cbd4e50d35f3eff2a", null ],
    [ "PlaceOfBirth", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#a92c43ab52987caba6303ea8ef5c9a3e1", null ],
    [ "Surname", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html#aefcef1213e807fdf8be7ac665ae462de", null ]
];