var class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_result =
[
    [ "OcrScanResult", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_result.html#a4573c2dd28413b138f7ae611dc92796e", null ],
    [ "ToJson", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_result.html#af0996d0d032a46f913ef1a4e4209b86e", null ],
    [ "ThresholdedImage", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_result.html#a6af9983c59f1cf83d2971ffdf0eed2fb", null ]
];