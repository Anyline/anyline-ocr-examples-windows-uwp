var interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields =
[
    [ "CardAccessNumber", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields.html#a52d142a0f0246f413bc3206555821873", null ],
    [ "DateOfBirth", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields.html#aa48b29005a8f7aaa5f82f1f363869848", null ],
    [ "DateOfBirthObject", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields.html#a34f8a9e11f1ff8a1f45177864ccac51f", null ],
    [ "DateOfExpiry", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields.html#afb0452c76f0bf537bb8cd232d885c2df", null ],
    [ "DateOfExpiryObject", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields.html#aa98a6ac7e7ce821aea5e83604171a979", null ],
    [ "DocumentNumber", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields.html#a6117209944b28de6d6641b643d98c1ce", null ],
    [ "GermanIdFrontString", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields.html#af2a22a462d915ef835b0bae8eecf9227", null ],
    [ "GivenNames", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields.html#ae3a5c8df50e10cf17557a7d6c861cd12", null ],
    [ "Nationality", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields.html#ae39d49cf7a2fb2b5b65c7b7f057f12ab", null ],
    [ "PlaceOfBirth", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields.html#a6a266dc89f7294f9c8c3078ed8745467", null ],
    [ "Surname", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_german_i_d_front_identification_fields.html#a94414cde88a26a8288ec218111ec0691", null ]
];