var class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_mrz_config =
[
    [ "MrzConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_mrz_config.html#a616c18ce19d9641dbe25bfc44e565cc7", null ],
    [ "MrzConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_mrz_config.html#ae98b9edcd755af6da980e1291d5d53c0", null ],
    [ "CropAndTransformID", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_mrz_config.html#a1b6f5027c3eed7c6d606ccd76b988c47", null ],
    [ "StrictMode", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_mrz_config.html#a8a006acbf2e070df91d59cd1883d1efb", null ]
];