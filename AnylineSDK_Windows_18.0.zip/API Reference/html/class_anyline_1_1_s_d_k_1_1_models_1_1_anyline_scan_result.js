var class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result =
[
    [ "AnylineScanResult", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result.html#a685b03519f5a49fefd19c9b3b9392e2b", null ],
    [ "ToJson", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result.html#a4cdf09ba56fba71bd1a0fc44e7b513df", null ],
    [ "Confidence", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result.html#a97474459dd85fb2add8537fe6155f4f5", null ],
    [ "CutoutImage", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result.html#a492648f0d1c54672a54fd5a61552f3e2", null ],
    [ "FullImage", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result.html#a91a431f2dd3733170b5596cb66448dc0", null ],
    [ "Outline", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result.html#a13c6cbc57dc317abb4e84b16bacd01ef", null ],
    [ "Result", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result.html#a8ba4b2ea5991dfcc151908b88416a058", null ],
    [ "Result", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result.html#a927c163f437458e6c2f72b221ff4493a", null ]
];