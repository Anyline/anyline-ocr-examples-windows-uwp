var class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin =
[
    [ "OcrScanPlugin", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin.html#a4fad267de182f48eb66223742653206b", null ],
    [ "CopyTrainedDataAsync", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin.html#a9562da40867f923ef9a12cee24b1d0b2", null ],
    [ "OnFinishedWithOutput", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin.html#a6ba1fb11ad057bf2b785beed45738c56", null ],
    [ "OnReportsVariable", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin.html#aa5404569cac17910e098c06f1fba8493", null ],
    [ "SetAnylineOcrConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin.html#aaa54f985ffc5e7873b64b2238b1a3855", null ],
    [ "Start", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin.html#a5569a0eabb06ba37bd607fd31ea48f16", null ],
    [ "AnylineOcrConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin.html#aedc82c9e767bade0a4fd81cb47a6d50f", null ],
    [ "ConfigUpdated", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin.html#a6a824a797443bd057fd06cdc1825d126", null ]
];