var namespace_anyline_1_1_s_d_k_1_1_plugins =
[
    [ "Barcode", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_barcode.html", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_barcode" ],
    [ "Composites", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_composites.html", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_composites" ],
    [ "ID", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d.html", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d" ],
    [ "LicensePlate", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate.html", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate" ],
    [ "Meter", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_meter.html", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_meter" ],
    [ "Ocr", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr.html", "namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr" ],
    [ "AbstractScanPlugin", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_abstract_scan_plugin.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_abstract_scan_plugin" ],
    [ "IConfigurableCharacterConfig", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_configurable_character_config.html", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_configurable_character_config" ],
    [ "IScanInfoListener", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_info_listener.html", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_info_listener" ],
    [ "IScanPlugin", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin" ],
    [ "IScanResultListener", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_result_listener.html", null ],
    [ "IScanRunSkippedListener", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_run_skipped_listener.html", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_run_skipped_listener" ],
    [ "ScanInfo", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_info.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_info" ],
    [ "ScanResult", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_result.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_result" ],
    [ "ScanRunSkippedReason", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_run_skipped_reason.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_run_skipped_reason" ],
    [ "VisualFeedback", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_visual_feedback.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_visual_feedback" ]
];