var class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_view_plugin =
[
    [ "OcrScanViewPlugin", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_view_plugin.html#af86679d021edf990b006d9dbc4b865fb", null ],
    [ "OcrScanViewPlugin", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_view_plugin.html#a2ce5663b2145a3b6be250a2b93652619", null ]
];