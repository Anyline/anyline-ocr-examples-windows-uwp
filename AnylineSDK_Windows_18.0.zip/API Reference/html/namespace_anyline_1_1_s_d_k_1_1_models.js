var namespace_anyline_1_1_s_d_k_1_1_models =
[
    [ "AnylineImage", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image" ],
    [ "AnylineScanResult", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result.html", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result" ],
    [ "IAnylineScanResult", "interface_anyline_1_1_s_d_k_1_1_models_1_1_i_anyline_scan_result.html", "interface_anyline_1_1_s_d_k_1_1_models_1_1_i_anyline_scan_result" ]
];