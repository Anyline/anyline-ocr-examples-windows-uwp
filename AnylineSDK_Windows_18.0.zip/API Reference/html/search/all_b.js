var searchData=
[
  ['name',['Name',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#ab2ac31b14ebcd948cbcc891b1e8ae219',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrLanguage']]],
  ['numerator',['Numerator',['../struct_anyline_1_1_s_d_k_1_1_util_1_1_resolution_ratio.html#aec138faa3c1131f93b106646afc1bdeb',1,'Anyline::SDK::Util::ResolutionRatio']]]
];
