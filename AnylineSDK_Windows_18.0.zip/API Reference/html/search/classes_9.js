var searchData=
[
  ['ocrscanplugin',['OcrScanPlugin',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin.html',1,'Anyline::SDK::Plugins::Ocr']]],
  ['ocrscanresult',['OcrScanResult',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_result.html',1,'Anyline::SDK::Plugins::Ocr']]],
  ['ocrscanviewplugin',['OcrScanViewPlugin',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_view_plugin.html',1,'Anyline::SDK::Plugins::Ocr']]]
];
