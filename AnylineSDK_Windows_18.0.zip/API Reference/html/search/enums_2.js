var searchData=
[
  ['languagefiletype',['LanguageFileType',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#a5b859231c1edcf0c466d8baf836d5b06',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrLanguage']]]
];
