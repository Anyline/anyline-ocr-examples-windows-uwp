var searchData=
[
  ['parse',['Parse',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_identification.html#a958d4983c3b3d95eb9e003978948f49c',1,'Anyline.SDK.Plugins.ID.GermanIDFrontIdentification.Parse()'],['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_mrz_identification.html#a41663c9704f588ed828e5f0e119a471e',1,'Anyline.SDK.Plugins.ID.MrzIdentification.Parse()']]],
  ['parsedateobject',['ParseDateObject',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d.html#ad7382aadc341a30d1f09584b09dc8b89',1,'Anyline::SDK::Plugins::ID::ID']]],
  ['price',['PRICE',['../struct_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_regex.html#af39e394feb54773402324ab5934ab4db',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrRegex']]]
];
