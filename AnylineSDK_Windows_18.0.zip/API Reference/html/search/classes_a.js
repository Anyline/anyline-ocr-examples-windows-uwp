var searchData=
[
  ['resolutionratio',['ResolutionRatio',['../struct_anyline_1_1_s_d_k_1_1_util_1_1_resolution_ratio.html',1,'Anyline::SDK::Util']]],
  ['runfailure',['RunFailure',['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_run_failure.html',1,'Anyline::SDK::Core::Exceptions']]]
];
