var searchData=
[
  ['maxcharheight',['MaxCharHeight',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#aa55f9ac78b3d41e58203c6e52050537a',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['md5',['Md5',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#a0cba5201c0cd59e860a56d5bbc68d7e6',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrLanguage']]],
  ['memorycollectionrate',['MemoryCollectionRate',['../namespace_anyline_1_1_s_d_k_1_1_util.html#ac1aae387015883581404690b7ce329d1',1,'Anyline::SDK::Util']]],
  ['message',['Message',['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_anyline_exception.html#a76be4e21a4d2d9cdf20a300cc10d3a45',1,'Anyline::SDK::Core::Exceptions::AnylineException']]],
  ['meterscanplugin',['MeterScanPlugin',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_meter_1_1_meter_scan_plugin.html',1,'Anyline::SDK::Plugins::Meter']]],
  ['meterscanresult',['MeterScanResult',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_meter_1_1_meter_scan_result.html',1,'Anyline::SDK::Plugins::Meter']]],
  ['meterscanviewplugin',['MeterScanViewPlugin',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_meter_1_1_meter_scan_view_plugin.html',1,'Anyline::SDK::Plugins::Meter']]],
  ['mincharheight',['MinCharHeight',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#ad29ae3da13359be017d9b4c422974396',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['minconfidence',['MinConfidence',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_config.html#a0e5e883a673a61c990364f7fc7efc1e3',1,'Anyline.SDK.Plugins.ID.IDConfig.MinConfidence()'],['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#a35cc5db2fd6add47a927eec7d49baf0a',1,'Anyline.SDK.Plugins.Ocr.AnylineOcrConfig.MinConfidence()']]],
  ['minsharpness',['MinSharpness',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#a5d27e0aa7a306ef9ee03766e6d18878d',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['mrzconfig',['MrzConfig',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_mrz_config.html',1,'Anyline::SDK::Plugins::ID']]],
  ['mrzfieldconfidences',['MrzFieldConfidences',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_mrz_field_confidences.html',1,'Anyline::SDK::Plugins::ID']]],
  ['mrzfieldscanoptions',['MrzFieldScanOptions',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_mrz_field_scan_options.html',1,'Anyline::SDK::Plugins::ID']]],
  ['mrzidentification',['MrzIdentification',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_mrz_identification.html',1,'Anyline::SDK::Plugins::ID']]]
];
