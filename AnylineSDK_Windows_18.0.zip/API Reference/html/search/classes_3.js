var searchData=
[
  ['drivinglicenseconfig',['DrivingLicenseConfig',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_driving_license_config.html',1,'Anyline::SDK::Plugins::ID']]],
  ['drivinglicensefieldconfidences',['DrivingLicenseFieldConfidences',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_driving_license_field_confidences.html',1,'Anyline::SDK::Plugins::ID']]],
  ['drivinglicensefieldscanoptions',['DrivingLicenseFieldScanOptions',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_driving_license_field_scan_options.html',1,'Anyline::SDK::Plugins::ID']]],
  ['drivinglicenseidentification',['DrivingLicenseIdentification',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_driving_license_identification.html',1,'Anyline::SDK::Plugins::ID']]]
];
