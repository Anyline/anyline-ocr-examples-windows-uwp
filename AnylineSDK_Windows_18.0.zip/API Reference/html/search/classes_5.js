var searchData=
[
  ['germanidfrontconfig',['GermanIDFrontConfig',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_config.html',1,'Anyline::SDK::Plugins::ID']]],
  ['germanidfrontfieldconfidences',['GermanIDFrontFieldConfidences',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_confidences.html',1,'Anyline::SDK::Plugins::ID']]],
  ['germanidfrontfieldscanoptions',['GermanIDFrontFieldScanOptions',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html',1,'Anyline::SDK::Plugins::ID']]],
  ['germanidfrontidentification',['GermanIDFrontIdentification',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_identification.html',1,'Anyline::SDK::Plugins::ID']]]
];
