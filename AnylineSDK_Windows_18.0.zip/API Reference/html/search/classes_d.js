var searchData=
[
  ['vinconfig',['VINConfig',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_v_i_n_config.html',1,'Anyline::SDK::Plugins::Ocr']]],
  ['visualfeedback',['VisualFeedback',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_visual_feedback.html',1,'Anyline::SDK::Plugins']]]
];
