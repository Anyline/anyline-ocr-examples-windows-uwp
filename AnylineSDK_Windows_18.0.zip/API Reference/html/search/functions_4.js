var searchData=
[
  ['germanidfrontidentification',['GermanIDFrontIdentification',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_identification.html#a326f250b8e0db2b55e5e561e1ee69254',1,'Anyline::SDK::Plugins::ID::GermanIDFrontIdentification']]],
  ['getbestfocusmode',['GetBestFocusMode',['../class_anyline_1_1_s_d_k_1_1_camera_1_1_focus_controller.html#aaf3d9d3a9e12bd2a84de94275c70c7b3',1,'Anyline::SDK::Camera::FocusController']]],
  ['getbitmapasync',['GetBitmapAsync',['../class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#a55235acd2af8acb7c2ffc37a3491aa99',1,'Anyline::SDK::Models::AnylineImage']]],
  ['getlanguageparametersasjsonstring',['GetLanguageParametersAsJsonString',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#af1fcbe02211b9c939df5eed533587bb7',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['getlanguagesasjsonstring',['GetLanguagesAsJsonString',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#a2b9bcc4e3b3815c5ab7dab635be2f1a8',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['getnewimage',['GetNewImage',['../class_anyline_1_1_s_d_k_1_1_camera_1_1_anyline_image_provider.html#a114cfddb8f838b21bffc645168d06c3f',1,'Anyline.SDK.Camera.AnylineImageProvider.GetNewImage()'],['../interface_anyline_1_1_s_d_k_1_1_core_1_1_i_image_provider.html#a280ea19914ffd63460560a5d4f6be2b9',1,'Anyline.SDK.Core.IImageProvider.GetNewImage()']]],
  ['gettesseractlanguagesasjsonstring',['GetTesseractLanguagesAsJsonString',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#a049190be682f65b0f5d63e3b0d41ca2c',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['gettesseractparametersasjsonstring',['GetTesseractParametersAsJsonString',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#a0fc95d204a5e75a4cd5a6d96dfe806cd',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]]
];
