var searchData=
[
  ['regex',['Regex',['../struct_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_regex.html#adc00d58432180fab50663de0c1f0ad42',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrRegex']]],
  ['releasecameraasync',['ReleaseCameraAsync',['../class_anyline_1_1_s_d_k_1_1_camera_1_1_camera_view.html#a4050e466a2120675e98a454ae9c7c6e5',1,'Anyline::SDK::Camera::CameraView']]],
  ['releasecamerainbackground',['ReleaseCameraInBackground',['../class_anyline_1_1_s_d_k_1_1_camera_1_1_camera_view.html#abd31a6384fb3623e63e6441d7bbb709c',1,'Anyline::SDK::Camera::CameraView']]],
  ['removesmallcontours',['RemoveSmallContours',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#a35c3b4d0beef2f33c86862834f4e4d70',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['removewhitespaces',['RemoveWhiteSpaces',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#af178764f0d9cb9507400b7ecff5c1c6f',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['resolutionratio',['ResolutionRatio',['../struct_anyline_1_1_s_d_k_1_1_util_1_1_resolution_ratio.html',1,'Anyline.SDK.Util.ResolutionRatio'],['../struct_anyline_1_1_s_d_k_1_1_util_1_1_resolution_ratio.html#a78f30ae510e36f62a339af006e874528',1,'Anyline.SDK.Util.ResolutionRatio.ResolutionRatio()']]],
  ['result',['Result',['../interface_anyline_1_1_s_d_k_1_1_models_1_1_i_anyline_scan_result.html#ab6a99bd84623356c083fd15c8f9a2145',1,'Anyline.SDK.Models.IAnylineScanResult.Result()'],['../class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result.html#a8ba4b2ea5991dfcc151908b88416a058',1,'Anyline.SDK.Models.AnylineScanResult.Result()']]],
  ['runfailure',['RunFailure',['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_run_failure.html',1,'Anyline.SDK.Core.Exceptions.RunFailure'],['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_run_failure.html#a7cfd9338f3b198598954cf47af9b16cc',1,'Anyline.SDK.Core.Exceptions.RunFailure.RunFailure()']]]
];
