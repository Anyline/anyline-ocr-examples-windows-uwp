var searchData=
[
  ['photocapturetarget',['PhotoCaptureTarget',['../namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_meter.html#abdaf720c805b3d2fd500a6a37020b2c3',1,'Anyline::SDK::Plugins::Meter']]]
];
