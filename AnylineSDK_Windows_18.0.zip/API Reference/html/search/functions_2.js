var searchData=
[
  ['email',['EMAIL',['../struct_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_regex.html#a43b023bbd6a67192f3fb300ca02b39ab',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrRegex']]]
];
