var searchData=
[
  ['licenseexception',['LicenseException',['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_license_exception.html#a676fe7f6b6cb68108016e4fbedfe2fab',1,'Anyline::SDK::Core::Exceptions::LicenseException']]]
];
