var searchData=
[
  ['licenseexception',['LicenseException',['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_license_exception.html',1,'Anyline::SDK::Core::Exceptions']]],
  ['licensefeature',['LicenseFeature',['../class_anyline_1_1_s_d_k_1_1_core_1_1_license_feature.html',1,'Anyline::SDK::Core']]],
  ['licenseplatescanplugin',['LicensePlateScanPlugin',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate_1_1_license_plate_scan_plugin.html',1,'Anyline::SDK::Plugins::LicensePlate']]],
  ['licenseplatescanresult',['LicensePlateScanResult',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate_1_1_license_plate_scan_result.html',1,'Anyline::SDK::Plugins::LicensePlate']]],
  ['licenseplatescanviewplugin',['LicensePlateScanViewPlugin',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate_1_1_license_plate_scan_view_plugin.html',1,'Anyline::SDK::Plugins::LicensePlate']]]
];
