var searchData=
[
  ['ocrscanmode',['OcrScanMode',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#a1ef20a06274d4a48327432e9f5a86cec',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]]
];
