var searchData=
[
  ['tojson',['ToJson',['../interface_anyline_1_1_s_d_k_1_1_models_1_1_i_anyline_scan_result.html#ad2b7cff83d3a50c6f8b901425e6481fa',1,'Anyline.SDK.Models.IAnylineScanResult.ToJson()'],['../class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_scan_result.html#a4cdf09ba56fba71bd1a0fc44e7b513df',1,'Anyline.SDK.Models.AnylineScanResult.ToJson()'],['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_result.html#a71ee721029f17a05909ff0d64d25d87d',1,'Anyline.SDK.Plugins.ScanResult.ToJson()']]],
  ['tojsonstring',['ToJsonString',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_base_config.html#a4cb21ad0deee3e3cf0b062e7299bea52',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrBaseConfig']]]
];
