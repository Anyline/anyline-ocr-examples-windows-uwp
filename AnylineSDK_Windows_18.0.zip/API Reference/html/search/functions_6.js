var searchData=
[
  ['idconfig',['IDConfig',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_config.html#aa591eed19a9f53ed50dbf14d7090935e',1,'Anyline.SDK.Plugins.ID.IDConfig.IDConfig()'],['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_i_d_config.html#abd845960caad3256e8e10a4eb153f9c2',1,'Anyline.SDK.Plugins.ID.IDConfig.IDConfig(JsonObject jsonObject)']]],
  ['imei',['IMEI',['../struct_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_regex.html#adf3d9fd359aca9935c8372bd12ba5e2e',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrRegex']]],
  ['init',['Init',['../class_anyline_1_1_s_d_k_1_1_views_1_1_scan_view.html#add272f42830425cb1c0e5dd7e7e19621',1,'Anyline.SDK.Views.ScanView.Init(JsonObject jsonObject, string licenseKey)'],['../class_anyline_1_1_s_d_k_1_1_views_1_1_scan_view.html#a1ca1ea3c7d5a15cff492431c312269a3',1,'Anyline.SDK.Views.ScanView.Init(string jsonAssetPath, string licenseKey)']]],
  ['isbn',['ISBN',['../struct_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_regex.html#a8800d12c27fb2fc83079575fa649cc02',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrRegex']]],
  ['iscameraopen',['IsCameraOpen',['../class_anyline_1_1_s_d_k_1_1_camera_1_1_camera_view.html#adbdde05e978642206b470efdb65f02ce',1,'Anyline::SDK::Camera::CameraView']]]
];
