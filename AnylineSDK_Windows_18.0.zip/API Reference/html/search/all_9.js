var searchData=
[
  ['languagefiletype',['LanguageFileType',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html#a5b859231c1edcf0c466d8baf836d5b06',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrLanguage']]],
  ['languages',['Languages',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#add768d5404bfccc5e3b82f7133fb6cd9',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['licenseexception',['LicenseException',['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_license_exception.html',1,'Anyline.SDK.Core.Exceptions.LicenseException'],['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_license_exception.html#a676fe7f6b6cb68108016e4fbedfe2fab',1,'Anyline.SDK.Core.Exceptions.LicenseException.LicenseException()']]],
  ['licensefeature',['LicenseFeature',['../class_anyline_1_1_s_d_k_1_1_core_1_1_license_feature.html',1,'Anyline::SDK::Core']]],
  ['licenseplatescanplugin',['LicensePlateScanPlugin',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate_1_1_license_plate_scan_plugin.html',1,'Anyline::SDK::Plugins::LicensePlate']]],
  ['licenseplatescanresult',['LicensePlateScanResult',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate_1_1_license_plate_scan_result.html',1,'Anyline::SDK::Plugins::LicensePlate']]],
  ['licenseplatescanviewplugin',['LicensePlateScanViewPlugin',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate_1_1_license_plate_scan_view_plugin.html',1,'Anyline::SDK::Plugins::LicensePlate']]],
  ['linenumber',['LineNumber',['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_syntax_exception.html#ad3eff7252dbf463d16f0503b451b976d',1,'Anyline::SDK::Core::Exceptions::SyntaxException']]],
  ['linestring',['LineString',['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_syntax_exception.html#a0eaeaad13fb8e0ea7cf3ebd46c4daa23',1,'Anyline::SDK::Core::Exceptions::SyntaxException']]]
];
