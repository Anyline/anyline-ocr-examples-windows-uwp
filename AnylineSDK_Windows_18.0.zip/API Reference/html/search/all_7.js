var searchData=
[
  ['hasnewimage',['HasNewImage',['../class_anyline_1_1_s_d_k_1_1_camera_1_1_anyline_image_provider.html#a601c50efd5a9c7e35b1736b0af6c80d5',1,'Anyline.SDK.Camera.AnylineImageProvider.HasNewImage()'],['../interface_anyline_1_1_s_d_k_1_1_core_1_1_i_image_provider.html#a60c4027df0e06c1719293cdcbaffea4f',1,'Anyline.SDK.Core.IImageProvider.HasNewImage()']]],
  ['height',['Height',['../class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#a282bd0adeabe655c4b38bc89ebb92303',1,'Anyline::SDK::Models::AnylineImage']]]
];
