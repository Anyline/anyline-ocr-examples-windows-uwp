var searchData=
[
  ['validationregex',['ValidationRegex',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#a43eca18ad40e059d6cfdb981cbeab8cc',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['verbosity',['Verbosity',['../namespace_anyline_1_1_s_d_k_1_1_util.html#a44753ef31f217f72f7825f856ba71715',1,'Anyline::SDK::Util']]],
  ['vin',['VIN',['../struct_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_regex.html#ad5148339954d599ff1329ff59a13ebfd',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrRegex']]],
  ['vinconfig',['VINConfig',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_v_i_n_config.html',1,'Anyline::SDK::Plugins::Ocr']]],
  ['visualfeedback',['VisualFeedback',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_visual_feedback.html',1,'Anyline::SDK::Plugins']]]
];
