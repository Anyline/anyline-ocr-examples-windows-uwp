var searchData=
[
  ['vin',['VIN',['../struct_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_regex.html#ad5148339954d599ff1329ff59a13ebfd',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrRegex']]]
];
