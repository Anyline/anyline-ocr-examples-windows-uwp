var searchData=
[
  ['save',['Save',['../class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#af29d24f17cc247185bca499029088cae',1,'Anyline::SDK::Models::AnylineImage']]],
  ['saveasync',['SaveAsync',['../class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#a76af1be39c697a8df218e8a0565e0b67',1,'Anyline::SDK::Models::AnylineImage']]],
  ['scanfeedbackconfig',['ScanFeedbackConfig',['../class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_scan_feedback_config.html',1,'Anyline::SDK::ViewPlugins']]],
  ['scaninfo',['ScanInfo',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_info.html',1,'Anyline::SDK::Plugins']]],
  ['scanmode',['ScanMode',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#a1fdaf96aec109d8d3ced8e8647b4c097',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['scanresult',['ScanResult',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_result.html',1,'Anyline::SDK::Plugins']]],
  ['scanresult_3c_20string_20_3e',['ScanResult&lt; string &gt;',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_result.html',1,'Anyline::SDK::Plugins']]],
  ['scanrunskippedreason',['ScanRunSkippedReason',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_run_skipped_reason.html',1,'Anyline::SDK::Plugins']]],
  ['scanview',['ScanView',['../class_anyline_1_1_s_d_k_1_1_views_1_1_scan_view.html',1,'Anyline::SDK::Views']]],
  ['scanviewpluginconfig',['ScanViewPluginConfig',['../class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_scan_view_plugin_config.html',1,'Anyline::SDK::ViewPlugins']]],
  ['setcameraconfig',['SetCameraConfig',['../class_anyline_1_1_s_d_k_1_1_camera_1_1_camera_view.html#a50437b52bc6b8ed4131bc7a7bbddf2d8',1,'Anyline::SDK::Camera::CameraView']]],
  ['setflashconfig',['SetFlashConfig',['../class_anyline_1_1_s_d_k_1_1_camera_1_1_flash_view.html#aff92b5aee16ed4f6d29f00f0d6cae136',1,'Anyline::SDK::Camera::FlashView']]],
  ['setlanguages',['SetLanguages',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#a575c7430bf280875befdd1905357261d',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['settesseractlanguages',['SetTesseractLanguages',['../class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html#a80a7a409c0c9ac97dea8d4bad204d9a4',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrConfig']]],
  ['setupwithconfig',['SetupWithConfig',['../class_anyline_1_1_s_d_k_1_1_views_1_1_scan_view.html#af45c1f152ef3b71ef1a5eedbdd06f0e1',1,'Anyline::SDK::Views::ScanView']]],
  ['startautofocustask',['StartAutoFocusTask',['../class_anyline_1_1_s_d_k_1_1_camera_1_1_focus_controller.html#ae292c8275d850389585a9e87695bb048',1,'Anyline::SDK::Camera::FocusController']]],
  ['stopautofocustask',['StopAutoFocusTask',['../class_anyline_1_1_s_d_k_1_1_camera_1_1_focus_controller.html#a05b4df552c43b36967cfc98629c44cc6',1,'Anyline::SDK::Camera::FocusController']]],
  ['syntaxexception',['SyntaxException',['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_syntax_exception.html',1,'Anyline.SDK.Core.Exceptions.SyntaxException'],['../class_anyline_1_1_s_d_k_1_1_core_1_1_exceptions_1_1_syntax_exception.html#a18b1e7607ce734e7f3efdd341461758a',1,'Anyline.SDK.Core.Exceptions.SyntaxException.SyntaxException()']]],
  ['system',['System',['../namespace_system.html',1,'']]],
  ['threading',['Threading',['../namespace_system_1_1_threading.html',1,'System']]]
];
