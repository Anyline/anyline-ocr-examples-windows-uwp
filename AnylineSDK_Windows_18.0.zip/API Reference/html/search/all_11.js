var searchData=
[
  ['updatefocusregionasync',['UpdateFocusRegionAsync',['../class_anyline_1_1_s_d_k_1_1_camera_1_1_focus_controller.html#ab6cf1060609bafe803aa44fefc23c52f',1,'Anyline::SDK::Camera::FocusController']]],
  ['url',['URL',['../struct_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_regex.html#a47dd887e8fa743fc38178694fdb6ef29',1,'Anyline::SDK::Plugins::Ocr::AnylineOcrRegex']]]
];
