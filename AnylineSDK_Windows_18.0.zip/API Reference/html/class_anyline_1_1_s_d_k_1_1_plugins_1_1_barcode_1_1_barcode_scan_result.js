var class_anyline_1_1_s_d_k_1_1_plugins_1_1_barcode_1_1_barcode_scan_result =
[
    [ "BarcodeScanResult", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_barcode_1_1_barcode_scan_result.html#a7cb2b29e7ca7a04c2f4c5c7eaa26738d", null ],
    [ "ToJson", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_barcode_1_1_barcode_scan_result.html#a5900eba767003e5eebf197ed0ce5c58f", null ],
    [ "BarcodeFormat", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_barcode_1_1_barcode_scan_result.html#ae1d4150ecbda7c80298e1ff3fcd15a4c", null ]
];