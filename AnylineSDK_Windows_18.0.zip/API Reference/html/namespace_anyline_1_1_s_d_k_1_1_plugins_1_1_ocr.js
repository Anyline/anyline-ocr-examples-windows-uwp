var namespace_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr =
[
    [ "AnylineOcrBaseConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_base_config.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_base_config" ],
    [ "AnylineOcrConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_config" ],
    [ "AnylineOcrLanguage", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_language" ],
    [ "AnylineOcrRegex", "struct_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_regex.html", "struct_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_anyline_ocr_regex" ],
    [ "CattleTagConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_cattle_tag_config.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_cattle_tag_config" ],
    [ "ContainerConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_container_config.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_container_config" ],
    [ "OcrScanPlugin", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_plugin" ],
    [ "OcrScanResult", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_result.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_result" ],
    [ "OcrScanViewPlugin", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_view_plugin.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_ocr_scan_view_plugin" ],
    [ "TINConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_t_i_n_config" ],
    [ "VINConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_v_i_n_config.html", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_v_i_n_config" ]
];