var namespace_anyline_1_1_s_d_k_1_1_util =
[
    [ "ResolutionRatio", "struct_anyline_1_1_s_d_k_1_1_util_1_1_resolution_ratio.html", "struct_anyline_1_1_s_d_k_1_1_util_1_1_resolution_ratio" ]
];