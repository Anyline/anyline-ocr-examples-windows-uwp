var class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_info =
[
    [ "ScanInfo", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_info.html#a4231bdc13c8b7872d90738415ee24c90", null ],
    [ "Key", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_info.html#af48657efea720d4ebacda425f4fe7089", null ],
    [ "PluginID", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_info.html#acb04fbca19602232aff3f859de8028d1", null ],
    [ "Value", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_scan_info.html#a7bf1dd909d60578e2391db8c4a7a0667", null ]
];