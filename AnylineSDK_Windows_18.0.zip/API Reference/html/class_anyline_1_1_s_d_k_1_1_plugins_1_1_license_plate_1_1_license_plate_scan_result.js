var class_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate_1_1_license_plate_scan_result =
[
    [ "LicensePlateScanResult", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate_1_1_license_plate_scan_result.html#ab38f278c6fe5b8225fa4dcad7841e252", null ],
    [ "ToJson", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate_1_1_license_plate_scan_result.html#a2d32855455436785cd9d83bd5b221326", null ],
    [ "Country", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_license_plate_1_1_license_plate_scan_result.html#a5db2cb56e9dc2e733dcc96cff5d21913", null ]
];