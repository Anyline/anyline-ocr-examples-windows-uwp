var interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_configurable_character_config =
[
    [ "CharacterWhitelist", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_configurable_character_config.html#a95ca914242aa145e5bb0cc45cd0582e5", null ],
    [ "ValidationRegex", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_configurable_character_config.html#aedbbae7686967e89be8e01df8a5cb948", null ]
];