var class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options =
[
    [ "GermanIDFrontFieldScanOptions", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#a88061c7914158570964d2d5599bffe7b", null ],
    [ "GermanIDFrontFieldScanOptions", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#ad664c1bdc03b47d96553bfbae84a7b52", null ],
    [ "CardAccessNumber", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#aed1943f0192aa977ddb484cbedc3c29c", null ],
    [ "DateOfBirth", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#a5c369a22cc343a96865a86d9b3e13ca3", null ],
    [ "DateOfBirthObject", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#a8f4ff7f8dc45a4e92e627976b19bdd98", null ],
    [ "DateOfExpiry", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#abb5ffcd4b695be12cf76b7bb40bb57b4", null ],
    [ "DateOfExpiryObject", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#af10b94021b151905cb370d309177f7db", null ],
    [ "DocumentNumber", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#a425ca247ee1a982cf1b34da0004ac6d4", null ],
    [ "GermanIdFrontString", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#a457a5ec0f9c1d697666f9baec14ba8cf", null ],
    [ "GivenNames", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#ad9729856c1b028086506399767549403", null ],
    [ "Nationality", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#a1ae45784d829205fdec1ec3c676d13fb", null ],
    [ "PlaceOfBirth", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#a585179598b704f11b207969d676c0d7f", null ],
    [ "Surname", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_i_d_1_1_german_i_d_front_field_scan_options.html#ae68359764cd7f3eac3c537c27661fab4", null ]
];