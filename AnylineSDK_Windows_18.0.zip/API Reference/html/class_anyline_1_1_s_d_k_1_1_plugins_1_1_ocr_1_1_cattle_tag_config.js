var class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_cattle_tag_config =
[
    [ "CattleTagConfig", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_ocr_1_1_cattle_tag_config.html#ab7a999fd41b1046a51c0be5724ba8b31", null ]
];