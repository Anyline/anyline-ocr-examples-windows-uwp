var interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin =
[
    [ "IsScanning", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html#ab2d976011266af38e3202bf59639d29d", null ],
    [ "Start", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html#a59adcd5f493a5b10f61fac1d93a2508b", null ],
    [ "Stop", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html#a7c8e18cd65f39b439e102aa8ff35d194", null ],
    [ "CropRect", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html#a05ab384b2da32cd679b9a062c085ed22", null ],
    [ "DelayStartScanTime", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html#a0425ebdaf8450101166206d0d3fc5fad", null ],
    [ "ExceptionListener", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html#a1975cc21ec9e1445025a8eaec93b0ffe", null ],
    [ "ID", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html#aa099401b3e1c50a02b1d37aba33f1e51", null ],
    [ "ImageProvider", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html#ae1767bd7152b54515b1da2aa01292f01", null ],
    [ "ScanInfoReceived", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html#a62975df2860c8c64fd45fdcaa85020bd", null ],
    [ "ScanResultReceived", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html#ad2b1b8564d6b6201623dc58ed059c487", null ],
    [ "ScanRunSkipped", "interface_anyline_1_1_s_d_k_1_1_plugins_1_1_i_scan_plugin.html#a2e4981bdc977a06a20a37e9733b1c7ff", null ]
];