var class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager =
[
    [ "CaptureManager", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#aa4f401ced01de3f9538312fad472754c", null ],
    [ "CapturePhotoAsync", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#ad325d77f21bf71e4d4cc75f46ab3611f", null ],
    [ "Dispose", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#a470be5dcf17f1de4b26ea8437112ed9b", null ],
    [ "GetCameraConfig", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#a7802ea452d361e6e5e3aa09579888899", null ],
    [ "SetCameraConfig", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#afedc34fe89782e83e6cd2281fe20a93e", null ],
    [ "StartPreviewAsync", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#ac6787f681af245e9285daffdde1cc969", null ],
    [ "StopPreviewAsync", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#aeec5247237ebaa0d38e741f742b84a81", null ],
    [ "TakeHighResolutionImageAsync", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#a7933101384cd7af5b25678202785a442", null ],
    [ "UpdateFocusRegionAsync", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#acaacb28cfaafff3ec48af2188a9211e2", null ],
    [ "ImageProvider", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#a5b9887d7a87869b7a0dfc15f8ee55a37", null ],
    [ "CropRect", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#a66f4298f396c64eec83bf0e6ce5e901d", null ],
    [ "CurrentOrientation", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#a188d2fdb2b5700b1c42ec82cb30fad84", null ],
    [ "Dispatcher", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#a1d7f8e7d7e721853aaaab470f354f1bd", null ],
    [ "FocusController", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#a4cfb0e4b144ba980b2c428dd510008bf", null ],
    [ "IsPreviewMirrored", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#a7925ecc15b701f51632c67b504a8ad04", null ],
    [ "IsPreviewOpen", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#a8e9472040059e0faf6187e34f4aa57be", null ],
    [ "MediaCapture", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#af92cdbecd1a9391ea7e04bdcbbbf7b67", null ],
    [ "PreviewError", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#aed6fbd9df16b28e1b98f45f8f13bc2c8", null ],
    [ "PreviewStarted", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#afcee4d663cda8756d3884f8b3625b7e0", null ],
    [ "PreviewStopped", "class_anyline_1_1_s_d_k_1_1_camera_1_1_capture_manager.html#a8888d9488dcb809a6e865f84d6cffb86", null ]
];