var class_anyline_1_1_s_d_k_1_1_plugins_1_1_composites_1_1_abstract_scan_view_plugin_composite =
[
    [ "AbstractScanViewPluginComposite", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_composites_1_1_abstract_scan_view_plugin_composite.html#ac10aedeff93b3f1a54628647adca6dd5", null ],
    [ "AddScanViewPlugin", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_composites_1_1_abstract_scan_view_plugin_composite.html#a78c4cef86a1189cdd4a59c2cdd5f85b4", null ],
    [ "Dispose", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_composites_1_1_abstract_scan_view_plugin_composite.html#a256af94c47582a33985d731382e09eb4", null ],
    [ "RemoveScanViewPlugin", "class_anyline_1_1_s_d_k_1_1_plugins_1_1_composites_1_1_abstract_scan_view_plugin_composite.html#ada45790ec59a608b7c2274e58bec8f91", null ]
];