var class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config =
[
    [ "AnimationStyle", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#ae3b8f71be7d6908e254bec104c7bbad4", [
      [ "None", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#ae3b8f71be7d6908e254bec104c7bbad4a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Fade", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#ae3b8f71be7d6908e254bec104c7bbad4a04e0385c10aefee8e4681617d2f3ef40", null ],
      [ "Zoom", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#ae3b8f71be7d6908e254bec104c7bbad4a4252b72e6ebcd4d4b4c2e46a786f03d2", null ]
    ] ],
    [ "CutoutAlignment", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a8416dee42f079de25160ed048cf756bf", [
      [ "Top", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a8416dee42f079de25160ed048cf756bfaa4ffdcf0dc1f31b9acaf295d75b51d00", null ],
      [ "TopHalf", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a8416dee42f079de25160ed048cf756bfa51f9ab089e0b40e3f7aa46e5291f30cb", null ],
      [ "Center", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a8416dee42f079de25160ed048cf756bfa4f1f6016fc9f3f2353c0cc7c67b292bd", null ],
      [ "BottomHalf", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a8416dee42f079de25160ed048cf756bfad4621240e4feb9c1a91350cdfebad59d", null ],
      [ "Bottom", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a8416dee42f079de25160ed048cf756bfa2ad9d63b69c4a10a5cc9cad923133bc4", null ]
    ] ],
    [ "CutoutStyle", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#aca3fee71eb19c7f9fc31146acc4bf894", [
      [ "Rect", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#aca3fee71eb19c7f9fc31146acc4bf894a69ad58d91eec91b5c152d21ca117dc81", null ],
      [ "Image", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#aca3fee71eb19c7f9fc31146acc4bf894abe53a0541a6d36f6ecb879fa2c584b08", null ]
    ] ],
    [ "CutoutConfig", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a352c590adf2b4ff5a601f92542f1b49d", null ],
    [ "CutoutConfig", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#acfa907f83333299529f614806228eb50", null ],
    [ "GetAnimationStyle", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#ad23397415534506ca36c83303ae47b0c", null ],
    [ "GetCutoutAlignment", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#ab3b9aa79b39767060413a92efdbcfb02", null ],
    [ "GetCutoutAlignment", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#ae8d0b3e2e165bf83e745571a1a7f968c", null ],
    [ "GetCutoutStyle", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a80bbaa1f01341bb43a32696dd9a56646", null ],
    [ "Alignment", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a915c1b0adbbde4e4aff8ef91941f6116", null ],
    [ "Animation", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a9c503b7700d8b8f70a2938c075d49348", null ],
    [ "CornerRadius", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#ada2bff7c89c418187e6507c1fb222fa7", null ],
    [ "CropOffset", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a7a6f2c1ba672f64e3da526bc047a12da", null ],
    [ "CropPadding", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#accad524c2aaee1481e48ad8cc45566a5", null ],
    [ "FeedbackStrokeColor", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#af71d08ba52b0ef65503e577e84cc79c3", null ],
    [ "Image", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#aee207946de91be03856184fee352d921", null ],
    [ "MaxHeightPercent", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#ae6bf601f9a4923732506796e33773f4d", null ],
    [ "MaxWidthPercent", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a01b699072aeaa494e25f5bde907a85cd", null ],
    [ "Offset", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#adb4726c75a433b8d9818d9d7a9c5d2d1", null ],
    [ "OuterColor", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a08e4629a1fc4f858c2abfa1d5dcf9dda", null ],
    [ "RatioFromSize", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a9dae8243a0cbf50a36f0e8b41b63ce76", null ],
    [ "StrokeColor", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#ad1388f2b548df3a716a561b4e077b803", null ],
    [ "StrokeWidth", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#aa94612f3869b2fb437c1f5ed1e0a1890", null ],
    [ "Style", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#ac46d13c8d3f9e64588649492c2e382c7", null ],
    [ "Width", "class_anyline_1_1_s_d_k_1_1_view_plugins_1_1_cutout_config.html#a1fce0503fce1dab2d5c543fad62bff0f", null ]
];