var class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image =
[
    [ "AnylineImage", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#a2589309b9cfadcacc81f9f4922194541", null ],
    [ "AnylineImage", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#aac8fc8e8e3d6129f5fa6871cc1cb4e39", null ],
    [ "Copy", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#a3c9943f8e77db1e0f7e05a39c9bf19ec", null ],
    [ "Crop", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#a80ab819fa1a3e8bc3587cec438ef83da", null ],
    [ "Dispose", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#aa61d2078bfa07032fae43eeeecce1936", null ],
    [ "GetBitmapAsync", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#a55235acd2af8acb7c2ffc37a3491aa99", null ],
    [ "Save", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#af29d24f17cc247185bca499029088cae", null ],
    [ "SaveAsync", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#a76af1be39c697a8df218e8a0565e0b67", null ],
    [ "Data", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#ad1e585978d5afbda1e55370cc2173293", null ],
    [ "Height", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#a282bd0adeabe655c4b38bc89ebb92303", null ],
    [ "Width", "class_anyline_1_1_s_d_k_1_1_models_1_1_anyline_image.html#a00edcd18ef11c49e0178705640aabf23", null ]
];